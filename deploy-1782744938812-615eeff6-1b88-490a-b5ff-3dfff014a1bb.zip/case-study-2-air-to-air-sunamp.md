# Air-to-air heat pump + Sunamp instead of a gas boiler: my unconventional setup, explained

*Case-study article draft · targets "air-to-air heat pump UK", "Sunamp heat battery review", "heat pump without water cylinder" · ~1,800 words*
*Featured on Skill Builder — embed video 2 (https://youtu.be/Z_kl8k0OsFY) near the top.*
*[BRACKETS] = notes for Gareth. [NEED] = your real figure before publishing.*

---

**Meta title:** Air-to-Air Heat Pump + Sunamp: My Setup Instead of a Gas Boiler
**Meta description:** Why I heated my home with an air-to-air heat pump and a Sunamp heat battery instead of a gas boiler and cylinder or an air-to-water system — the real costs, the grant catch, and who it suits. As featured on Skill Builder.

---

> **The setup at a glance** — my real install
> - Heating/cooling: Daikin multi-split air-to-air — one **3MXM52A9** outdoor unit feeding **three Daikin Stylish (FTXA) wall units** in the **main living areas**: 2.0kW (bedroom), 2.5kW (lounge), 3.5kW (garden room) — £5,300, zero VAT (ESM relief), Oxford Air Conditioning, Nov 2025
> - Hot water: **Sunamp Thermino 300e** heat battery (~12kWh / ~300L-equivalent) + volt-free control — **£4,774 inc VAT**, replaced the old hot-water cylinder, EcoSmart Heat, Feb 2026
> - Designed to: −5°C outside (heating) / 34°C (cooling), 22°C rooms · R32 refrigerant · 7-yr Daikin parts warranty
> - **Combined spend: ~£10,074** for heating/cooling the main rooms + all hot water
> - **As featured on Skill Builder** ▶ [embed video 2]

## Why I didn't fit the "normal" heat pump

When people say "heat pump" in the UK they almost always mean **air-to-water** — a unit that heats water and pushes it round radiators or underfloor pipes, with a big hot-water cylinder for your taps. It's the system the £7,500 grant is built around, and for a lot of homes it's the right call.

I went a different way: an **air-to-air heat pump** heating the three main living areas, and a **Sunamp heat battery** for hot water. No wet central heating circuit, no traditional cylinder. To be straight with you up front — this isn't a whole-house wet system that heats every room off one boiler; it's targeted heating and cooling in the rooms I actually live in, plus a compact heat battery doing all the hot water. People find this surprising, so let me explain why it can make sense — and, because this is Decarbonarma, exactly where the catch is.

[Embed Skill Builder video 2 here — it walks through the A2A units and the Sunamp.]

## Air-to-air: the heat pump people forget exists

An air-to-air heat pump is, mechanically, very close to an air-conditioning unit — it moves heat between the outside air and the air inside your rooms via wall or ceiling units. The upsides are real:

- **It's efficient.** [NEED your real figure — your site cites a metered ~444% SCOP elsewhere; if that's your system, say so, it's a killer stat.] Done well, A2A can match or beat air-to-water on raw efficiency because it skips the losses of heating water and pushing it round a circuit.
- **It does cooling too.** The same units cool in summer — something a standard air-to-water system simply can't do. In a warming climate that's not a gimmick.
- **It's cheaper and less disruptive to fit.** My whole three-room Daikin system — one outdoor unit, three indoor heads, all pipework and commissioning — came to **£5,300, with zero VAT** under the Energy Saving Materials relief. No radiators to upsize, no wet pipework to run, no big cylinder to plumb. Compare that to a typical air-to-water install at £10,000–£14,000 before the grant, and the contrast is stark — though the grant is exactly where the comparison gets interesting (more below).
- **Room-by-room control.** You heat the rooms you're using, when you're using them.

The honest trade-offs: it heats *air*, not water, so it can feel different to a radiator's gentle background warmth; the indoor units are visible on the wall; and it does nothing for your hot water — which is exactly where the Sunamp comes in.

## Sunamp: hot water without the cylinder

Full honesty: the Sunamp wasn't a carefully planned green upgrade — it was a **distress buy**. My hot-water cylinder finally gave up after 20 years, choked with limescale from two decades of hard water. When your cylinder fails you need hot water back fast, so this was a forced decision under time pressure — and I'd rather tell you that than pretend it was all part of a master plan. The interesting bit is what I chose to replace it with, and whether, with hindsight, it was the right call.

A **Sunamp Thermino** is a *heat battery*. Instead of storing hot water in a big insulated tank, it stores heat in a salt-based **phase-change material**, then heats your mains water instantly as it passes through, at full mains pressure. Why I went for it over a like-for-like new cylinder:

- **It's tiny** — up to four times smaller than the equivalent hot-water cylinder, which matters when you've not got an airing cupboard to spare.
- **Far lower standing losses** — roughly 0.77 kWh lost over 24 hours versus about 1.42 kWh for a typical cylinder. It holds onto your heat better.
- **No legionella risk and no annual maintenance** — there's barely any stored water to harbour bacteria.
- **It loves a smart tariff** — you charge it on cheap off-peak electricity overnight, then draw hot water all day from stored heat. On a tariff like [NEED — your tariff], that's where the running cost really drops.

Mine cost **£4,774 including VAT** — a Thermino 300e supplied, installed and commissioned, with the old hot-water cylinder removed and taken away. (Worth noting: unlike the air-to-air units, this was charged at the standard 20% VAT, not zero-rated — about £796 of the total — so check the VAT treatment on any quote you get.)

**A word on hard water, since that's what killed my last cylinder.** A heat battery isn't a magic limescale cure — your incoming mains water still passes through a heat exchanger, so in a hard-water area scale management still matters. Sunamp take this seriously: they **insist on an electronic limescale preventer** being fitted as part of the install, precisely to protect the heat exchanger that does all the work. Mine has one. So the failure mode is genuinely different from my old cylinder — no big tank of water sitting and scaling for 20 years, plus active scale prevention on the way in. If you're in a hard-water area, treat that inline scale protection as non-negotiable, exactly as Sunamp do.

## The catch nobody mentions: the grant

Here's the bit the brochures skip, and the bit that makes this article honest and useful.

The **£7,500 Boiler Upgrade Scheme is for air-to-*water* and ground-source heat pumps**. A standalone air-to-air system **does not** qualify for the big grant — that's the single biggest reason A2A stays niche in the UK despite its efficiency.

What I *did* get was the **0% VAT** under the Energy Saving Materials relief — so my £5,300 was £5,300, with no 20% on top. That's a real saving (worth roughly £1,000 here), just nothing like the headline £7,500 an air-to-water system attracts.

So the comparison isn't just "which is more efficient" — it's "is A2A's lower install cost enough to beat air-to-water *after* air-to-water's £7,500 head start?" And here I can give you a real number for my own house, not a brochure range.

I had a **Heat Geek** installer come out and survey the house properly for a conventional air-to-water heat pump. The proposal came back at **£27,000 before grant** — so roughly **£19,500 after the £7,500 Boiler Upgrade Scheme**. My air-to-air units plus the Sunamp came to about **£10,000 all-in**. For my house, the "grant-backed" option was still nearly double the price.

The generic figures say air-to-water lands around £3,000–£7,000 net after the grant — but those are easy houses. Mine clearly wasn't: a full wet system with the radiator and pipework upgrades it needed pushed the real quote to £27k. The catch, to be fair, is that the two systems aren't doing the same job. The air-to-water proposal would heat *every* room off radiators plus do the hot water; my A2A heats and *cools* the three main living areas — the rooms I actually spend time in — and the Sunamp handles hot water separately. If your priority is even heat in every room off one system, air-to-water is still your answer. But if it's efficient, controllable comfort where it counts (plus summer cooling) without a £20k bill, this is a genuinely overlooked route.

## What it actually costs to run

[Real numbers here are the whole point — fill what you track:]

- **Heating:** [NEED — annual cost, or kWh × tariff. Versus your old system if you know it.]
- **Hot water (Sunamp):** [NEED — annual cost, ideally on your off-peak tariff]
- **Total vs the system it replaced:** [NEED — before/after]
- **Tariff:** [NEED — which one; the off-peak rate is doing a lot of the work]

Even rough figures beat every prediction-based article out there, because they're *yours and metered*.

## Who should actually consider this

Be honest with yourself. This setup suits you if:

- Your home is **well-insulated and not huge** — A2A shines when heat demand is modest.
- You **want cooling** in summer, not just heating.
- You're **short on space** for a big cylinder, or doing a retrofit where wet pipework is a pain.
- You're **happy to run a smart tariff** and charge the Sunamp off-peak.
- You can live with **wall-mounted indoor units** and air-based heat.

It's probably *not* for you if you've got a big, leaky house needing serious heat, you want the £7,500 grant to do the heavy lifting, or you specifically want radiator-style background warmth. In those cases air-to-water is likely the better call — [link to "is a heat pump worth it 2026" pillar].

[**Lead-capture block:** "Curious whether air-to-air or air-to-water suits your home? Our heat-loss tool gives you an independent steer — no salesperson, no spam." → email + postcode → installer panel.]

## The one-line version

Air-to-air plus a Sunamp is the heat-pump setup the UK mostly ignores — efficient, space-saving, does cooling, and great on a smart tariff — but you trade away the £7,500 grant, so it wins for the right home and loses for the wrong one. Mine was the right home. [NEED: confirm/adjust that last line to your real verdict.]

---

### Sources / figures to cite on the live page
- Sunamp Thermino — phase-change heat battery, ~4× smaller than a cylinder, ~0.77 kWh/24h standing loss vs ~1.42 kWh cylinder, no legionella; BUS-fundable as ancillary alongside a qualifying heat pump (Sunamp / HeatElectric)
- Sunamp spec & cost: EcoSmart Heat quote ESH-0302-GPITTS (3 Feb 2026) — Thermino 300e (~12kWh) + VF01 volt-free control, £4,774 inc VAT (20%), incl. removal of old cylinder
- Boiler Upgrade Scheme £7,500 is for air-to-water / ground source, not standalone air-to-air (Ofgem / Energy Saving Trust)
- A2A system spec & cost: Oxford Air Conditioning quote PROSPITTS (7 Aug 2025) / invoice 120297 (29 Nov 2025) — Daikin 3MXM52A9 outdoor + 3× FTXA Stylish indoor units, £5,300 at 0% VAT (ESM relief)
- All running-cost / efficiency figures: Gareth's real metered system [to be filled]

### Internal links to add
Is a heat pump worth it 2026 (pillar) · Heat pump running cost vs gas · Best heat pump tariff · Heat-loss tool · Author bio (Skill Builder)
