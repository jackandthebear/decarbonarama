# Is a heat pump worth it in the UK? An honest 2026 answer — from someone who actually fitted one

*Cornerstone article draft · targets "is a heat pump worth it UK 2026" · ~1,900 words*
*Voice check: data-led, no-BS, lived experience. Brackets [like this] are notes for Gareth, not for publishing.*

---

**Meta title:** Is a Heat Pump Worth It in the UK? An Honest 2026 Answer
**Meta description:** No sales pitch. A homeowner who fitted his own heat pump runs the real 2026 numbers — grant, running costs vs gas, and when it genuinely isn't worth it.

---

## The short answer

For most UK homes in 2026, yes — but not for the reason the adverts give you, and not for everyone.

A heat pump is worth it if you can get it installed well, run it on a smart tariff, and you're not expecting it to be cheaper than gas on day one of a botched install. Get those three things right and it's cheaper to run than a gas boiler, far cleaner, and — after the £7,500 government grant — often costs about the same to fit as a premium new boiler. Get them wrong and you'll be one of the unhappy people writing angry forum posts.

I know which camp you end up in is mostly about *how* it's done, not *whether* you should do it, because I fitted one to my own home. This is what I'd tell a friend.

## What "worth it" actually means — pick your test

People ask "is it worth it?" meaning three completely different things. Be honest about which one is yours, because the answer changes:

1. **Will it save me money vs gas?** Sometimes, and increasingly yes in 2026 — but only on the right tariff.
2. **Will it pay back its cost?** That depends almost entirely on the grant and what you're replacing.
3. **Is it the right thing to do for a low-carbon home?** Almost always yes — it's roughly 3× more efficient than burning gas.

Let's take the money questions properly, because that's where the honest answer lives.

## The cost to install in 2026 — after the grant

The number that scares people is the sticker price: a typical air source heat pump install runs **£10,000–£14,000** before any help. But almost nobody pays that, because of the **Boiler Upgrade Scheme (BUS)**.

In 2026 the BUS gives you **£7,500 off** an air source or ground source heat pump in England and Wales. You don't apply — your MCS-certified installer claims it and knocks it straight off your quote. [Link to our Boiler Upgrade Scheme explainer here.]

There's also a temporary uplift worth knowing: from **21 July 2026 to 31 March 2027**, homes **off the gas grid** (on heating oil or LPG) can get **£9,000** instead. If that's you, the maths is even better — and frankly, if you're currently on oil, a heat pump is close to a no-brainer.

So the real-world figure for most people is roughly **£3,000–£7,000 installed**, after the grant. That's comparable to — sometimes less than — a high-end gas boiler swap. The headline price and the price you actually pay are very different things, and a lot of "too expensive" conclusions are people staring at the wrong number.

## Running costs: heat pump vs gas in 2026

Here's where it used to be genuinely close, and where 2026 has tilted things.

A heat pump turns one unit of electricity into roughly **3–3.5 units of heat** (that's the SCOP — seasonal coefficient of performance — and real metered UK data clusters around 3.5–3.9 for well-installed systems). Gas is cheaper per unit, but you burn more than one unit of gas per unit of heat. So the comparison comes down to the **price gap between gas and electricity**, and the **efficiency you actually achieve**.

Three scenarios for a typical home:

- **Heat pump on the standard price cap:** broadly level-pegging with a gas boiler. At a SCOP around 3.5 you're paying roughly the same as gas — neither a windfall nor a disaster.
- **Heat pump on a smart heat-pump tariff (e.g. Cosy Octopus, ~7.5p/kWh off-peak):** this is the unlock. Running costs drop dramatically — real customers report **£200–£600/year cheaper** than the same home on a gas boiler. [Link to our best heat pump tariff article + tariff finder tool.]
- **Gas boiler:** steady, familiar, and getting relatively *more* expensive. From 1 July 2026 the gas portion of the price cap rose roughly 24% while electricity rose only around 5% — the gap that makes heat pumps look good is widening, not closing.

The headline: **a heat pump on a dumb tariff is fine; a heat pump on a smart tariff is cheaper than gas.** If you take nothing else away, take that. The tariff is half the decision.

## The bit the adverts won't tell you: it's the install, not the brand

This is the most important paragraph on the page, so I'll be blunt. The single biggest factor in whether your heat pump is cheap and lovely or expensive and annoying is **the quality of the installation and the flow temperature it runs at** — not the badge on the outdoor unit.

Real metered data from hundreds of UK systems shows performance varies by up to **2× within the same brand**, and the strongest predictor of how efficient a system is isn't the manufacturer at all — it's how low the flow temperature runs. [Link to our "Does brand matter?" article.] A great installer fitting a mid-range unit will comfortably beat a lazy installer fitting a premium one.

What this means for you, practically:

- Choose your **installer** far more carefully than your **brand**.
- Insist the system is designed for a **low flow temperature** (ideally 35–45°C), which usually means slightly bigger radiators in a couple of rooms.
- Ask to see their **previous systems' monitored performance** if they have it. The good ones are proud of it.

## When a heat pump is NOT worth it (yet)

Independent means telling you when to wait. Be cautious if:

- **You're moving house within 2–3 years.** You won't see the running-cost payback, and it won't reliably add its cost to the sale price yet.
- **Your home is very poorly insulated *and* you can't do anything about it.** A heat pump works fine in an old house — mine isn't new — but it needs to be able to lose heat slowly. If you've got solid walls, no loft insulation and zero budget to improve any of it, fix the cheap insulation first; it makes everything else work better. [Link to our "heat pump for an old house" article.]
- **You can't get a competent installer locally.** A heat pump is only as good as its install. If the only quotes you can get are vague, rushed, or won't commit to a flow temperature, wait until you find someone who will.
- **You have a working boiler with years left and no smart tariff appetite.** No shame in timing the switch for when your boiler dies anyway.

None of these are "never" — they're "not yet", and most are fixable.

## So, should *you* do it?

Run yourself through this honestly:

- Are you staying put for 5+ years? ✓
- Can you find an installer who'll design for a low flow temperature and show their work? ✓
- Are you willing to run a smart tariff? ✓
- Is your home either reasonably insulated, or improvable? ✓

Four ticks: it's almost certainly worth it, and the 2026 grant maths is the best it's been. Two or three ticks: worth it with some prep first. Fewer: sort the gaps before you spend.

[**Lead-capture block here:** "Want to know what it'd cost *for your home*? Try our heat-loss tool — pop in your postcode and we'll show you the numbers, no salesperson, no spam." → email + postcode capture → routes to vetted installer panel.]

## What I'd tell a friend, in one line

Don't ask "are heat pumps worth it?" — ask "can I get a *good one, installed well, on a smart tariff?*" If yes, the rest of the maths takes care of itself in 2026. If no, fix that first.

---

### Sources / figures to cite on the live page
- Boiler Upgrade Scheme £7,500 (and £9,000 off-gas-grid, 21 Jul 2026–31 Mar 2027) — Ofgem / Energy Saving Trust
- Heat pump vs gas running costs on Cosy Octopus (~7.5p off-peak) — Octopus Energy
- July 2026 price cap: gas +~24%, electricity +~5%
- Real-world SCOP/SPF spread within brands — HeatpumpMonitor.org / OpenEnergyMonitor

### Internal links to add
Boiler Upgrade Scheme explainer · Best heat pump tariff · Does brand matter? · Heat pump for an old house · Heat-loss / battery tools
