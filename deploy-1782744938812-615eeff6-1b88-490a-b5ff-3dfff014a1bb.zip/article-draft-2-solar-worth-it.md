# Are solar panels worth it in the UK in 2026? The real numbers on cost, savings and payback

*Cornerstone article draft · targets "are solar panels worth it UK 2026" / "solar battery payback UK" · ~1,900 words*
*Voice check: data-led, no-BS, lived experience. Brackets [like this] are notes for Gareth, not for publishing.*

---

**Meta title:** Are Solar Panels Worth It in the UK in 2026? Honest Cost & Payback
**Meta description:** No sales pitch. The real 2026 cost of solar (and a battery), honest payback maths by region, and when it's genuinely not worth it — from a homeowner who fitted it.

---

## The short answer

For most UK homes with a decent south-ish roof, solar is worth it in 2026 — payback lands around **7–10 years** and the panels keep going for 25+. Add a battery and you'll use far more of your own power, but you'll stretch the payback, so a battery is worth it for *some* people and not others. The honest version of this answer depends on three things: your roof, your tariff, and how much electricity you use during the day. Let's do the actual maths instead of the brochure version.

## What solar actually costs in 2026

Real installed prices this year, MCS-certified, including the 0% VAT relief that's still running:

- **A typical 4kW system: ~£6,500–£8,500** (the rough national average is around £7,500–£8,700 fitted).
- **Smaller 3kW: from ~£5,500.**
- **Larger 6kW: up to ~£11,500.**
- **Add a battery (4–5kWh): another ~£3,000–£5,000**, so a solar-plus-battery system commonly lands **£8,000–£14,000+**.

The 0% VAT scheme is quietly worth **£1,000–£3,000** of that — it's a genuine discount, not a gimmick, and it won't necessarily last forever, which nudges the timing argument toward "sooner".

A note on quotes: solar pricing is messier than it should be, and the spread between a fair quote and a rip-off is wide. Get three quotes, and be suspicious of anyone selling on pressure and "today only" discounts. [Link to our solar quality / how-to-buy guide.]

## The savings — and why they vary so much

A 4kW system generates roughly **3,400–4,200 kWh a year** depending where you are. What that's *worth* to you depends entirely on two things:

1. **How much you use while the sun's up** (self-consumption). Every unit you use yourself saves you the full ~25p+ you'd have paid the grid. Every unit you export earns you far less.
2. **Your export rate** (the Smart Export Guarantee). Exported units typically earn somewhere in the **5–15p/kWh** range depending on tariff — useful, but much less than self-consumed units.

Typical annual savings for a 4kW system land around **£500–£700**, and you can push the top of that range by shifting usage (dishwasher, washing machine, EV charging, hot water) into daylight hours. This is the bit people underestimate: solar rewards you for *changing when you use power*, not just for generating it.

## Payback: the honest, regional version

Independent means giving you the unflattering numbers too. Payback isn't one figure — it depends heavily on where your roof is:

- **South of England, good roof:** ~**7–9 years**. The sweet spot.
- **Midlands / average:** ~**9–11 years**.
- **Scotland / north / shaded roof:** ~**11–14 years**. Still positive over the panels' life, but slower — go in with eyes open.

Against a 25-year-plus panel lifespan, even the slow cases come out ahead. But if someone promises you a 5-year payback in Aberdeen, they're selling, not calculating.

## The battery question — where it gets interesting

This is the decision most people get wrong in both directions, so here's the straight version.

A battery doesn't generate anything. What it does is **store your cheap or self-generated electricity to use later**, so you buy less expensive grid power at peak times. It's worth it when:

- **You're out during the day**, so without a battery most of your solar would be exported cheaply rather than used.
- **You're on (or willing to move to) a smart tariff** with cheap overnight rates — then a battery earns its keep *even in winter* by charging up cheap at night and discharging at peak. [Link to our "should I get a battery without solar?" article — because on the right tariff, you can.]
- **You have an EV or a heat pump**, which makes time-shifting much more valuable.

It's *not* worth it if you're home all day using power as you generate it, you're on a flat tariff, and you're chasing the fastest possible payback — a battery will add £3–5k and extend your payback by a few years.

[**Lead-capture block here:** "Not sure what size battery actually makes sense for your usage? Our battery sizing tool runs your numbers — no salesperson, no spam." → links to existing battery_sizing_tool.html → email capture.]

## When solar is NOT worth it (yet)

- **Your roof faces mostly north, or is heavily shaded.** Physics doesn't care about enthusiasm — output drops too far to justify the spend.
- **You're moving within a couple of years.** Solar can add value to a sale, but not reliably enough to bank on for payback.
- **Your roof needs replacing soon.** Do the roof first; you don't want to pay to remove and refit panels in three years.
- **You use almost no electricity during daylight and won't shift any.** Without self-consumption or a battery + smart tariff, the savings thin out.

## How to actually maximise the return

If you do go ahead, these are the levers that move the numbers — in order of impact:

1. **Buy well.** Three quotes, MCS-certified, ignore pressure selling. The install price is the biggest single variable in your payback.
2. **Shift your usage into daylight.** Free savings, no extra kit. Timers and a bit of habit change.
3. **Get on the right tariff.** Export rate and smart import rates change the maths materially. [Link to tariff finder.]
4. **Only add a battery if your usage pattern justifies it** — and size it properly rather than buying the biggest one offered.

## So, should *you* do it?

Quick self-test:

- Roof facing roughly south/east/west and not badly shaded? ✓
- Staying put 7+ years? ✓
- Willing to shift some usage to daytime, or add a battery + smart tariff? ✓

Three ticks: solar is very likely worth it in 2026, and the 0% VAT window makes the timing favourable. If the battery question is the one you're stuck on, that's usually about your daily routine and tariff, not the panels — so decide the panels first, then run the battery numbers separately.

[**Closing lead-capture:** "Want your real payback figure for your postcode and roof? Try our solar calculator — independent numbers, no quote-chasing." → email + postcode → vetted installer panel.]

## What I'd tell a friend, in one line

Get the panels if your roof and time horizon stack up — they almost certainly will. Treat the battery as a separate decision that lives or dies on your tariff and your daily routine, not on hype.

---

### Sources / figures to cite on the live page
- 4kW install ~£6,500–£8,500; average ~£7,500–£8,677; battery +£3,000–£5,000 — multiple 2026 UK installer/price guides
- 0% VAT relief worth £1,000–£3,000
- Annual savings ~£500–£700; payback 7–10yr (regional 7–14yr)
- Self-consumption vs Smart Export Guarantee export rates

### Internal links to add
Solar quality / how-to-buy guide · Battery sizing tool · Should I get a battery without solar? · Best smart tariff / tariff finder · Is a heat pump worth it (pillar cross-link)
