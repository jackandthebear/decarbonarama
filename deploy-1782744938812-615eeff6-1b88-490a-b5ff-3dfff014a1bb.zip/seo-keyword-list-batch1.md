# Decarbonarma — SEO Keyword List (Batch 1)

*Marketing manager · 27 June 2026 · 10 launch targets*

## How to read this

We're deliberately **not** chasing the giant head terms ("heat pump", "solar panels") — they're owned by national sites with huge domain authority and we'd never rank from zero. Instead we target **high-intent, mid-tail queries** where the searcher is close to buying, competition is beatable, and the click is worth real money to us via lead-gen and affiliate. Win these first, build authority, then climb toward the bigger terms.

Each keyword is mapped to: search intent, why we can win it, the article that targets it, and how it eventually earns.

## The 10 launch keywords

| # | Target keyword | Intent | Why we can win | Money route |
|---|----------------|--------|----------------|-------------|
| 1 | is a heat pump worth it UK 2026 | High — deciding | Honesty + real lived data beats sales content | Installer lead-gen |
| 2 | are solar panels worth it UK 2026 | High — deciding | Independent payback maths, our calculator | Installer lead-gen + affiliate |
| 3 | heat pump running cost vs gas boiler | High — comparing | Real metered numbers, current tariffs | Lead-gen + tariff affiliate |
| 4 | solar battery payback UK | High — comparing | Our battery sizing tool as the hook | Affiliate (battery/inverter) |
| 5 | Boiler Upgrade Scheme explained 2026 | Mid — researching grant | Plain-English, up-to-date £7.5k/£9k detail | Lead-gen (grant → install) |
| 6 | best heat pump tariff UK | High — ready to switch | Independent tariff comparison, our finder tool | Tariff affiliate (high bounty) |
| 7 | do I need to upgrade radiators for a heat pump | Mid — overcoming objection | Removes a top fear with real experience | Lead-gen |
| 8 | air source heat pump cost after grant | High — budgeting | Clear post-grant maths, no quote-gate | Lead-gen |
| 9 | should I get a battery without solar | Mid — niche, low comp | Underserved query, our optimiser angle | Affiliate + paid tool |
| 10 | heat pump worth it for old house / poorly insulated | High — common objection | Lived-experience answer competitors dodge | Lead-gen |

## Priority order for writing

1. **#1 and #2** are the two cornerstone pillars — written now (see the two article drafts). They're the highest-value, most-searched decision queries and everything else links up to them.
2. **#3, #4, #5, #6** are the next wave — each is a strong standalone piece that internally links back to the pillars.
3. **#7–#10** are "objection-buster" support articles: shorter, fast to write, and they catch people at the exact moment of doubt before they commit.

## The internal-linking shape

```
        [Pillar: Is a heat pump worth it]      [Pillar: Are solar panels worth it]
                │                                          │
   ┌────────────┼────────────┐               ┌─────────────┼─────────────┐
 running    radiators?    cost after       battery       battery        best
 cost vs    (#7)          grant (#8)        payback       w/o solar      tariff
 gas (#3)                                    (#4)          (#9)          (#6)
   │                                                                      │
 Boiler Upgrade Scheme (#5) ──────────── feeds both pillars ──── old house? (#10)
```

Each support article points readers *up* to a pillar; each pillar points *down* to the supports and *out* to a tool + lead-capture. That cluster structure is what tells Google we're the authority on this topic — far more powerful than 10 unconnected posts.

## Notes for each as we write

- **Always** include current 2026 figures (BUS £7,500; £9,000 off-gas-grid from 21 Jul 2026; solar 4kW ~£6.5–8.5k; Cosy Octopus 7.5p off-peak). Dated, specific numbers are what make us look credible *and* what Google rewards for "freshness".
- **Always** anchor to Gareth's real install — it's the one thing no competitor can copy.
- **Always** end with a soft lead-capture (tool + email), never a hard "GET QUOTES NOW" banner — that would break the independent positioning that's our whole moat.
