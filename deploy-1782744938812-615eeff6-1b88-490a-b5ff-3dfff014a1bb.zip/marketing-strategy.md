# Decarbonarma — Marketing Strategy

*Prepared by your marketing manager · 27 June 2026*

## The brief, in one line

Take an independent, no-BS UK home-decarbonisation site from near-zero to a real audience within ~6 months — built on Gareth's lived experience of decarbonising his own home — then monetise that audience through installer lead-gen, affiliate, paid tools and sponsorship.

## Who we're for

The primary reader is a **UK homeowner, 6–12 months out from a £5k–£15k decision** — a heat pump, solar+battery, or an EV charger. They're anxious, over-Googling, drowning in installer sales-speak, and they don't trust anyone. Our entire job is to be the one source that feels genuinely on *their* side.

Everything below serves that one reader.

## Positioning

**"The home-decarbonisation site that actually did it."**

Three pillars to hammer in every piece:

1. **Independent.** Not owned by an installer or manufacturer. We say when something isn't worth it.
2. **Evidence over vibes.** Real numbers from a real house — Gareth's — plus our own tools and case studies.
3. **Plain English.** We translate the jargon (SCOP, MCS, flow temps, agile tariffs) without dumbing it down.

This is our wedge against the competition: MoneySavingExpert is broad and shallow on this topic, Heat Geek is installer-led, manufacturer blogs are sales funnels, and forums are intimidating. Nobody owns *"impartial, lived-experience, with great tools."*

## Channel strategy (you left the mix to me)

**Primary engine: SEO.** It's the only channel where a high-intent homeowner finds us at the exact moment they're ready to act, and it compounds for free — perfect for an audience-first, lead-gen-later play on a modest budget. This is where 60% of effort goes.

**Trust amplifier: YouTube.** Since you're happy to be the face, your real install is a genuine asset most competitors can't fake. Video builds the trust that converts a reader into a lead, and YouTube doubles as a second search engine. Start lightweight (screen-recorded tool walkthroughs, monitoring data, "one year with my heat pump"). ~25% of effort.

**Ignition + research: Reddit & forums.** Free, fast, and the fastest way to learn the exact language and worries of our reader. Be genuinely useful in r/HeatPumpsUK, r/solar, r/uknews-adjacent threads, OpenEnergyMonitor and EVForums — link only when it truly helps. ~15% of effort. This also seeds early traffic while SEO matures.

**Email list runs across all of them** — it's how we own the audience rather than renting it from Google. Every page and video drives to a single high-value lead magnet (see below).

Paid promotion stays off until something is organically working; the £100–£500 goes to tools and the occasional freelancer, not ads — yet.

## The 6-month plan

### Month 1 — Foundations
- Lock positioning, brand voice, and a one-line promise on every page.
- Set up the stack: an email platform (MailerLite/Kit, free tier), Google Search Console + analytics, and a single email-capture lead magnet — your **"What my heat pump actually cost & saved" real-numbers breakdown**.
- Pick our first 10 SEO target keywords (high-intent, low-competition: e.g. "is a heat pump worth it UK 2026", "solar battery payback UK", "Octopus agile vs cosy").
- Publish the first 2 cornerstone articles + add email capture to the existing tools.

### Months 2–3 — Build the content engine
- 1–2 pieces/week, every one mapped to a search query and an eventual money page.
- Turn your existing tools into lead magnets: gate the detailed result behind email + postcode.
- Launch the YouTube channel with 3–4 foundational videos (your install, a tool walkthrough, "biggest mistakes" piece).
- Begin steady, honest Reddit/forum presence. Target: first 100 email subscribers.

### Months 4–6 — Traction & early monetisation
- Double down on whatever 20% of content is pulling 80% of the traffic.
- Add affiliate links across all relevant articles (tariffs, EV chargers, myenergi kit) — earns from day one of traffic.
- Stand up the **installer lead-gen funnel** quietly (panel of vetted installers or a network partner) — this is the highest £/visitor route and the real prize.
- Target by month 6: meaningful organic traffic trend, 300–500+ engaged subscribers, first affiliate/lead revenue proving the model.

## How we'll make money (ordered by £ per visitor)

1. **Installer lead-gen** — £15–£60+ per qualified heat-pump/solar lead. Built into the tools. The big one; we build toward it deliberately.
2. **Affiliate** — tariff switches (Octopus etc.), EV chargers, batteries, smart kit. Switch on early, low effort.
3. **Paid tools / personalised reports** — premium tier on the optimiser/heat-loss tools once they have a track record.
4. **Ads & sponsorship** — only past ~30–50k sessions/month, via a premium network; sponsored content from brands once the audience is proven.

We don't chase all four at once. Audience and trust first; revenue follows the trust.

## How you'll know it's working (6-month scorecard)

- **Leading:** publishing cadence held, pages indexing and ranking, email signups per week trending up, Reddit/YouTube engagement.
- **Lagging:** organic sessions, email list size, first affiliate/lead-gen pounds.
- If traction is real at month 6, *then* we discuss reinvesting revenue into paid acquisition and scaling content.

## One risk to manage from day one

UK rules bite in this niche: the **ASA** polices green/savings claims (every "save £X" needs a defensible basis), and if we ever touch finance/BNPL for installs, **FCA** scope can apply. Staying scrupulously evidence-based isn't just our brand — it's our compliance moat. I'll flag anything that strays.

## What I need from you next

1. Confirm the lead magnet idea (your real heat-pump cost/savings breakdown) — or suggest a better hook.
2. Tell me your actual install details (kit, costs, savings, monitoring) so I can turn them into content.
3. Green-light Month 1 and I'll start drafting the first cornerstone articles and the keyword list.
