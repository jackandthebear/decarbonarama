# I re-roofed my house with Superfoil and solar — here's what actually happened

*Case-study article draft · targets "Superfoil insulation review", "solar roof retrofit UK", "is multifoil insulation worth it" · ~1,700 words*
*Featured on Skill Builder — embed video 1 (https://youtu.be/2rwH3EdV_rE) near the top.*
*[BRACKETS] = notes for Gareth. Anything marked [NEED] is where I need your real figure before publishing.*

---

**Meta title:** Superfoil + Solar Roof Retrofit: What It Really Cost & Saved
**Meta description:** A homeowner re-roofs with Superfoil insulation and solar and gets his whole-home energy bill down to £20/month — the real cost, the metered output, and whether multifoil is worth it. As featured on Skill Builder.

---

> **The setup at a glance** — my real install
> - Property: [age / type — e.g. 1930s house, slate roof — NEED]
> - Insulation: SuperFOIL **SF40BB** breather membrane over the rafters + **SF60** laid over the existing ~10cm glass-fibre wool on the joists (layered "COMBI" build); roof needed replacing anyway
> - New solar (this project): **18× Aiko 510W panels** (~9.2kWp), 9 north-facing / 9 south-facing, on **Enphase IQ8HC microinverters** — main roof, Oct 2025 · plus **4 bonus panels on the garage** (May 2026)
> - Already in place: **12× Viridian 405W** (~4.9kWp) + **Sonnen battery, 15kWh**, 3.6kW inverter, 3kW backup power (lights & sockets) — fitted ~2022
> - Costs: re-roof ~£6,500 + slates · Superfoil ~£2,000 · new solar ~£10,000 (earlier 2022 system ~£20,000)
> - **Result: whole-home energy bill is now a £20/month Octopus direct debit**
> - **As featured on Skill Builder** ▶ [embed video 1]

## Why I touched the roof at all

Most people add solar by bolting panels onto whatever roof they already have. I did it differently, and on purpose: **my roof needed replacing anyway**. Once you've accepted the cost of a re-roof — scaffold, stripping, new covering — the smart move is to do everything that's easier with the roof open at the same time, rather than insulate and re-roof and *then* pay again to add solar later. So I did the whole lot in one go: strip the roof, upgrade the insulation with Superfoil, and put the new solar on at the same time.

That decision is the whole story here, because doing it together changes the economics completely. If you're re-roofing anyway, the *marginal* cost of doing it well is far lower than people assume.

[Embed Skill Builder video 1 here — it shows the roof stripped and the install in progress.]

## What Superfoil actually is (and the honest bit)

Superfoil is a **multifoil insulation** — thin layers of reflective foil and wadding that work mainly by reflecting radiant heat rather than by sheer thickness. The appeal for a roof like mine is that it's slim: you get meaningful thermal performance without losing the rafter depth (and headroom) that a thick board or mineral wool would eat up. For older properties with shallow rafters, that's a genuine advantage.

The honest caveat — and I'll always give you the honest caveat — is that multifoil performance is a long-running argument in the building world. Manufacturer R-values are measured under ideal conditions, and the real-world figure depends heavily on getting **continuous, sealed air gaps** either side of the foil. Fitted lazily, it underperforms its headline number. Fitted properly, with the air gaps and laps taped and sealed, it does the job — and in a "COMBI" build alongside some board or wool you can hit Building Regs comfortably.

My build used two products doing two different jobs: **SF40BB as the breather membrane** laid over the rafters (a vapour-permeable foil that keeps weather out while letting the structure breathe), and **SF60 — the thickest multifoil in the range — over the joists**. Crucially, I didn't rip out what was already there: there was about **10cm of old glass-fibre wool sitting on the joists**, and we laid the SF60 over the top of it. That's exactly the **layered "COMBI" approach SuperFOIL recommend** — multifoil working *with* existing mineral wool rather than instead of it — and it gets you better real-world performance than either layer alone, while reusing insulation that was already paid for.

What mattered most wasn't the rolls themselves but that it was **installed with continuous, sealed air gaps and taped laps** — same lesson as heat pumps, honestly: the install beats the badge. A reflective foil with leaky gaps is just expensive foil.

## The scratched-panel bonus (a true story)

Worth telling because it's the kind of thing that never makes it into the brochures. When my 18 Aiko panels were delivered, four arrived scratched. Rather than have them sent back and scrapped, the supplier let me keep them. So I bought four more Enphase IQ8 microinverters and we mounted the "reject" panels on the **garage roof — which nobody can even see** from the ground.

Here's the punchline: those four cosmetically-damaged, headed-for-the-skip panels are my **best producers on the whole site**. Each has generated around **590 kWh** in the monitoring period, versus ~325 kWh for each south-roof panel and ~175 kWh for each north one. Hidden away on a garage roof no visitor will ever clock, they're quietly making the most electricity of anything I own — and the panels were free. The lesson: cosmetic damage rarely affects a panel's output, ugly roofs nobody looks at are perfect for solar, and it always pays to ask.

## What it cost

Here's the real breakdown for the roof project:

| Item | Cost |
|---|---|
| Re-roofing (labour, scaffold, new slates) | ~£6,500 + slates |
| SuperFOIL insulation (SF40BB + SF60) | ~£2,000 |
| New solar array (18 main-roof + 4 garage panels + Enphase microinverters) | ~£10,000 |

The crucial point is what was *optional*. **The roof had to be replaced regardless** — that ~£6,500-plus-slates was money I was always going to spend. So the genuine "green uplift" was really just the **£2,000 of Superfoil** bolted onto a re-roof I had to do anyway. For two grand, on top of work that was already happening, I got the insulation that now means I don't heat the bedroom at all (more on that below). That's the whole argument for doing it together: the insulation rode in cheaply on the back of an unavoidable job.

The solar (~£10,000) is the bigger discretionary spend, and it sits on top of my **earlier system from around 2022**: 12 Viridian panels with a Sonnen battery (15kWh), which was about **£20,000** at the time. I'll be straight — that 2022 price looks expensive now; battery-and-inverter costs have come down a lot and you'd get more for your money today. But it's the battery that makes the whole setup sing, because it lets me store cheap/solar power and lean on it at peak.

## What changed — the results

This is where the real metered numbers do the talking:

- **Generation:** the new Enphase-monitored array has produced **6.91 MWh lifetime** since it went live, and on a good summer's day (25 June 2026) it made **64.5 kWh** across the system. That's real metered output, not a sales estimate.
- **North roof actually works:** half my main-roof panels face *north* — the orientation every solar salesperson warns against. Because each panel runs its own microinverter, the north side still pulls its weight. Over the monitoring period my north panels have made about **175 kWh each versus ~325 kWh for the south ones** — so roughly **54% of the south output across the year**. On a peak summer day the gap narrows to about 70%. It's clearly less, and I wouldn't *choose* north over south — but "north roof = don't bother" is a myth. With microinverters, a north-ish roof is well worth using, not writing off.
- **The headline number:** between the two solar arrays, the 15kWh Sonnen battery, the Sunamp heat battery and an Octopus smart tariff, **my entire home energy bill is a £20/month direct debit.** That's heating, hot water and electricity for the house — for less than most people spend on coffee in a week.

- **Heat retention — the bit that genuinely surprised me:** before the Superfoil went in, we heated the bedroom like any other room. Now it's **completely unheated** — and in the middle of the heating season we sometimes have to crack a **window open to sleep comfortably** because it's too warm. That's not a brochure claim, it's a nightly reality: the roof now holds onto heat so well that a room we used to actively warm needs *cooling* instead. If you want a single, honest measure of what good roof insulation does, that's it.

## Would I do it again? And would I recommend it to you?

Yes to the first, without hesitation. My one real regret is the **inverter, not the panels**: my Sonnen battery's inverter is rated at **3.6kW**, which isn't quite enough to carry the *whole* house load at once, so heavy moments still lean on the grid. Back when I bought it, 3.6kW was simply what was available at that size — but if I were specifying it today I'd go beefier to cover full-house demand, and I'd take more battery kWh while I was at it. More storage is always handy. It's a useful lesson for you: when you're sizing a battery system, think about the **inverter's power rating (kW)**, not just the **storage size (kWh)** — they're two different numbers and people fixate on the second while the first is what decides whether you can actually run the house off it.

For you, the decision comes down to timing. **If your roof needs work anyway, do all three together** — re-roof, insulate, solar. The shared scaffold, shared labour and single disruption make the combined job far cheaper than doing them as three separate projects across a decade. If your roof is fine and you just want solar, that's a different (simpler) calculation — [link to "are solar panels worth it 2026" pillar].

And whatever you do: insist your installer seals the multifoil properly. A reflective foil with leaky air gaps is just expensive foil.

[**Lead-capture block:** "Thinking about solar as part of a re-roof? Our solar calculator gives you an independent payback figure for your roof — no salesperson, no spam." → email + postcode → installer panel.]

---

### Sources / figures to cite on the live page
- SuperFOIL multifoil — reflective performance, slim profile for shallow rafters, ~0.16 W/m²K target to meet Part L (SuperFOIL / Insulation Superstore)
- Solar specs & data: Gareth's real install — new array 18× Aiko 510W + 4 garage panels on Enphase IQ8HC microinverters (~£10k, Oct 2025/May 2026); earlier 12× Viridian 405W + Sonnen hybrid inverter, 15kWh battery (~£20k, ~2022); Enphase: 6.91 MWh lifetime, 64.5 kWh on 25 Jun 2026
- Per-panel output (Enphase, 2025–26 monitoring): garage (free scratched panels) ~586–592 kWh each; south main roof ~325–327 kWh each; north main roof ~171–184 kWh each → north ≈54% of south over the year
- Headline result: whole-home energy bill = £20/month Octopus direct debit
- Costs (real): re-roof ~£6,500 + new slates; Superfoil ~£2,000; new solar ~£10,000; earlier 2022 solar+Sonnen ~£20,000. Roof needed replacing regardless, so the green "uplift" was effectively the ~£2k Superfoil.
- Insulation build: SF60 laid over existing ~10cm glass-fibre on joists (SuperFOIL "COMBI" approach)
- Heat retention (real): bedroom was heated pre-Superfoil; now unheated and occasionally needs a window open in heating season for comfort
- Optional still: property type/age

### Internal links to add
Are solar panels worth it 2026 (pillar) · Solar quality / how-to-buy guide · Battery sizing tool · Author bio (Skill Builder)
